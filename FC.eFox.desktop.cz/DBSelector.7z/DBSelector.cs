﻿using NUnit.Framework;
using System;
using System.Configuration;
using System.Data.SqlClient;

namespace FC.eFox.desktop.cz
{
	/// <summary>
	/// Class represents about databse connection and getting data drom DB
	/// </summary>
	public static class DBSelector
	{
		private static string DataSource = null;
		private static string DataBase = null;

		/// <summary>
		/// Method to get the database connection details
		/// </summary>
		public static void GetConnectionDetails()
		{
			var environment = GetEnvironment();
			switch (environment)
			{
				case "TestDB":
					DataSource = ConfigurationManager.AppSettings["TestDataSource"];
					DataBase = ConfigurationManager.AppSettings["TestDataBase"];
					break;
				case "AccDB":
					DataSource = ConfigurationManager.AppSettings["AccDataSource"];
					DataBase = ConfigurationManager.AppSettings["AccDataBase"];
					break;
				case "ProdDB":
					DataSource = ConfigurationManager.AppSettings["ProdDataSource"];
					DataBase = ConfigurationManager.AppSettings["ProdDataBase"];
					break;
				default:
					Console.WriteLine("NO valid environment parameter was provided. Test env will be used.");
					DataSource = ConfigurationManager.AppSettings["TestDataSource"];
					DataBase = ConfigurationManager.AppSettings["TestDataBase"];
					break;
			}
		}

		/// <summary>
		/// Gets the proper environment
		/// </summary>
		/// <returns></returns>
		private static string GetEnvironment()
		{
			var environment = TestContext.Parameters.Get("environment", "test");
			return environment;
		}

		/// <summary>
		/// 
		/// </summary>
		private static void ConnectToDB()
		{
			try
			{
				var connection = new SqlConnection("data source=" + DataSource + ";" + "Initial Catalog=" + DataBase + ";Integrated Security=SSPI");
				connection.Open();
			}
			catch (Exception e)
			{
				Console.WriteLine(e.ToString());
			}
		}
	}
}
